package com.ibm.eis.ui;

import java.util.Scanner;

import com.ibm.eis.bean.Employee;
import com.ibm.eis.service.EmployeeServiceClass;
import com.ibm.eis.service.EmployeeServiceInterface;

public class FindEmployeeDetails {

	private static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		do {
			
			EmployeeServiceInterface esi = new EmployeeServiceClass();
			Employee emp1 = new Employee();
			Employee emp2 = new Employee();
			Employee emp3 = new Employee();
			Employee emp4 = new Employee();
			
			emp1.setId(1);
			emp1.setName("Bijoy");
			emp1.setSalary(10000);
			emp1.setDesignation("System Associate");
			
			emp2.setId(2);
			emp2.setName("Apoorva");
			emp2.setSalary(25000);
			emp2.setDesignation("Programmer");
			
			emp3.setId(3);
			emp3.setName("Gargee");
			emp3.setSalary(50000);
			emp3.setDesignation("Manager");
			
			emp4.setId(4);
			emp4.setName("Hussam");
			emp4.setSalary(4000);
			emp4.setDesignation("Clerk");
			
			esi.storeIntoMap(emp1,emp2,emp3,emp4);
			
			
			int id = 0, newSalary = 0;
			String salary =null, desig = null, name1 = null;
			String name = null;
			System.out.println("\n");
			System.out.println("Press 1 for See Employee Details");
			System.out.println("Press 2 for See Insurance Scheme");
			System.out.print("Enter Your Choice: ");
			int ch = sc.nextInt();
			switch(ch){
				case 1: System.out.println("\n");
						System.out.print("Enter the Employee ID you want to see details: ");
						id = sc.nextInt();
						sc.nextLine();
						System.out.println(esi.displayEmployee(id));
						
						break;
				case 2: System.out.print("\nEnter the Employee ID, you want to see the Insurance Scheme: ");
						id = sc.nextInt(); 
						sc.nextLine();
						System.out.print("\nEnter the Employee Name, you want to see the Insurance Scheme: ");
						name = sc.nextLine();
						String[] arr = esi.getInsurance(id,name);
						salary = arr[0];
						desig = arr[1];
						name1 = arr[2];
						
						newSalary = Integer.parseInt(salary);
						System.out.println("Employee Name Correspondable to your given Id is: " + name1);
						System.out.println("Employee Designation Correspondable to your given Id is: " + desig);
						System.out.println("Employee Salary Correspondable to your given Id is: " + newSalary);
						
						if((newSalary > 5000 && newSalary < 20000) && (desig.equals("System Associate")))
						{
							System.out.println("\n Employee's suitable Scheme is: Scheme C");
						}
						else if((newSalary >= 20000 && newSalary < 40000) && (desig.equals("Programmer")))
						{
							System.out.println("\n Employee's suitable Scheme is: Scheme B");
						}
						else if((newSalary >= 40000) && (desig.equals("Manager")))
						{
							System.out.println("\n Employee's suitable Scheme is: Scheme A");
						}
						else if((newSalary < 5000) && (desig.equals("Clerk")))
						{
							System.out.println("\n Employee's suitable Scheme is: No Scheme");
						}
						else
						{
							System.out.println("There is No MATCH!!");
						}
						
						break;
				default: System.out.println("You have entered a wrong choice");
			}
			
		}while(true);
		
	}

}
