package com.ibm.eis.dao;

import com.ibm.eis.bean.Employee;


public interface EmployeeDaoInterface {
	
	public void storeIntoMap(Employee emp1, Employee emp2, Employee emp3, Employee emp4);
	public String displayEmployee(int id);
	public String[] getInsurance(int id, String name);

}
