package com.ibm.eis.dao;

import java.util.HashMap;
import java.util.Map;
import com.ibm.eis.bean.Employee;

public class EmployeeDaoClass implements EmployeeDaoInterface {

	private Map<Integer,Employee> employee= new HashMap<Integer,Employee>();
	
	public void storeIntoMap(Employee emp1, Employee emp2, Employee emp3, Employee emp4) {
		
		employee.put(1, emp1);
		employee.put(2, emp2);
		employee.put(3, emp3);
		employee.put(4, emp4);
		
		
	}
		
	public String displayEmployee(int id) {
				
		String str = employee.get(id).toString();
		
		return str;
	}

	public String[] getInsurance(int id, String name) {
		
		String salary = new Integer(employee.get(id).getSalary()).toString();
		String desig = employee.get(id).getDesignation();
		String name1 = employee.get(id).getName();
		String arr[] = new String[5];
		arr[0] = salary;
		arr[1] = desig;
		boolean flag = false;
		do {
			if(name.equals(name1)) {
			
				arr[2] = name1;
				flag = true;
			}
			else
			{
				System.out.println("Check the Name Again!!");
				flag = false;
			}
		}while(flag == false);
		
		return arr;
		
	}

	
	
}
