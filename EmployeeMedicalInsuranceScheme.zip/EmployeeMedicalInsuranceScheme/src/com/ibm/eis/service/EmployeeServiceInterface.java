package com.ibm.eis.service;

import com.ibm.eis.bean.Employee;

public interface EmployeeServiceInterface {
	

	public String displayEmployee(int id);
	public String[] getInsurance(int id, String name);
	public void storeIntoMap(Employee emp1, Employee emp2, Employee emp3, Employee emp4);
}
