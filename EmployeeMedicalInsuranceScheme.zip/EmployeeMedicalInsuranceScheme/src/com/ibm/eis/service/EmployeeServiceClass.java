package com.ibm.eis.service;

import com.ibm.eis.bean.Employee;
import com.ibm.eis.dao.EmployeeDaoClass;

public class EmployeeServiceClass implements EmployeeServiceInterface {
	
	EmployeeDaoClass empDao = new EmployeeDaoClass();

	@Override
	public String displayEmployee(int id) {
		
		return empDao.displayEmployee(id);
	}

	@Override
	public String[] getInsurance(int id, String name) {
		
		return empDao.getInsurance(id,name);
	}

	@Override
	public void storeIntoMap(Employee emp1, Employee emp2, Employee emp3, Employee emp4) {
		
		empDao.storeIntoMap(emp1,emp2,emp3,emp4);
		
	}

	

	
	
	

}
