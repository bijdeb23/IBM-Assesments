package com.ibm.takehome.bean;

public class Product {
	
	private int productId;
	private String productName;
	private String productCategory;
	private String productDescription;
	private int productPrice;
	
	public int getProductId() {
		return productId;
	}
	public String getProductName() {
		return productName;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public int getProductPrice() {
		return productPrice;
	}
	
	public Product(int productId, String productName, String productCategory, String productDescription, int productPrice) {
		
		this.productId = productId;
		this.productName = productName;
		this.productCategory = productCategory;
		this.productDescription = productDescription;
		this.productPrice = productPrice;
		
	}


}
