package com.ibm.takehome.ui;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.ibm.takehome.bean.Product;
import com.ibm.takehome.service.BillingSoftwareServiceClass;
import com.ibm.takehome.service.BillingSoftwareServiceInterface;

public class BillingSoftwareHomePage {
	private static Scanner sc = new Scanner(System.in);
	private static boolean flag = false, flag2 = false;
	
	public static void main(String[] args) {
		
		do {
			BillingSoftwareServiceInterface bsi = new BillingSoftwareServiceClass();
			
			int pCode = 0,quant = 0;
			System.out.println("\n");
			System.out.println("Press 1 for Generate Bill by entering Product code and quantity");
			System.out.println("Press 2 for Exit");
			System.out.print("Enter Your Choice: ");
			int ch = 0;
			while (true) {
		        try {
		        	ch = sc.nextInt();
		            sc.hasNextLine();	
		            break;
		        }
		        catch (InputMismatchException e) {

		        	System.out.print("Please Give the Correct Input: ");
		            sc.next();
		    	}
		    }
			switch(ch)
			{
				case 1:  do {
								System.out.println("\n");
								System.out.println("Press 1 for Enter Product Details");
								System.out.println("Press 2 for Exit");
								System.out.print("Enter Your Choice: ");
								int choice = sc.nextInt();
								switch(choice) {
								case 1: System.out.println("\n");
										while(true){
											
											System.out.print("Enter Product Code: ");
											pCode = 0;
											while (true) {
										        try {
										        	pCode = sc.nextInt();
										            sc.hasNextLine();	
										            break;
										        }
										        catch (InputMismatchException e) {

										        	System.out.print("Please Give the Correct Input: ");
										            sc.next();
										    	}
										    }
											
											boolean isValid= bsi.validateProductCode(pCode);
											
											if(isValid)
												break;
											}
										
										while(true)
										{
												System.out.print("Enter the Quantity");
												quant = 0;
												while (true) {
											        try {
											        	quant = sc.nextInt();
											            sc.hasNextLine();
											            break;
											        }
											        catch (InputMismatchException e) {

											        	System.out.print("Please Give the Correct Input: ");
											            sc.next();
											    	}
											    }
														
												boolean validationQuantity = bsi.validateQuantity(quant);
												
												if(validationQuantity)
													break;
										}
										
										Product p = bsi.getProductDetails(pCode);
										System.out.println("\n");
										System.out.println("Product Name: "+ p.getProductName());
										System.out.println("Product Category: "+ p.getProductCategory());
										System.out.println("Product Description: "+ p.getProductDescription());
										System.out.println("Product Price: "+ p.getProductPrice());
										System.out.println("Quantity: "+ quant);
										System.out.println("Total Price: "+ (quant * p.getProductPrice()));
										
										flag2 = false;
										break;
										
										
										
										
										
								case 2:	flag2 = true;
										break;
								default: System.out.println("Invalid Choice");
								
							}
								
								
					
						}while(flag2 == false);
				
				case 2: flag = true;
						break;
						
				default:	System.out.println("Invalid Choice");
			}
			
			
		}while(flag == false);
		

	}

}
