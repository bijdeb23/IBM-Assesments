package com.ibm.takehome.service;

import com.ibm.takehome.bean.Product;
import com.ibm.takehome.dao.BillingSoftwareDaoClass;
import com.ibm.takehome.dao.BillingSoftwareDaoInterface;

public class BillingSoftwareServiceClass implements BillingSoftwareServiceInterface {

	BillingSoftwareDaoInterface bsdi = new BillingSoftwareDaoClass();

	@Override
	public boolean validateProductCode(int pCode) {
		int count = 0;
		while(pCode > 0) {
			
			pCode = pCode / 10;
			count = count + 1; 
			
		}
		
		if(count == productCodePattern)
			return true;
		else
			return false;
	}

	@Override
	public boolean validateQuantity(int quant) {
		if(quant>0)
			return true;
		else 
			return false;
	}

	@Override
	public Product getProductDetails(int pCode) {
		
		return bsdi.getProductDetails(pCode);
	}

	
}
