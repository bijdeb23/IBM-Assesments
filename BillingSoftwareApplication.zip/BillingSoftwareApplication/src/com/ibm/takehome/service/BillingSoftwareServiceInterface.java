package com.ibm.takehome.service;

import com.ibm.takehome.bean.Product;

public interface BillingSoftwareServiceInterface {

	int productCodePattern= 4;
	boolean validateProductCode(int pCode);
	boolean validateQuantity(int quant);
	Product getProductDetails(int pCode);

}
