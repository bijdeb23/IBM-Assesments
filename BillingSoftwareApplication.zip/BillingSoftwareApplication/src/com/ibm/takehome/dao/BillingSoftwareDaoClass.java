package com.ibm.takehome.dao;

import com.ibm.takehome.bean.Product;
import com.ibm.takehome.util.CollectionUtil;

public class BillingSoftwareDaoClass implements BillingSoftwareDaoInterface {

	@Override
	public Product getProductDetails(int pCode) {
		
		Product p = CollectionUtil.products.get(pCode);
		
		return p;
	}


	
		
	}

