package com.ibm.dao;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.ibm.bean.Training;
import com.ibm.dao.DatabaseUtility;

public class TrainingDao {
	static PreparedStatement stmt;
	static ArrayList<Training> list=new ArrayList<>();
	
	public static ArrayList<Training> trainingDetails() {
		
		DatabaseUtility dbU = new DatabaseUtility();
		try {
		
		Connection conn = dbU.connectToDatabase();
		String sql = "SELECT * from Training";
		
		stmt = conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {

        	int trainingId = rs.getInt("trainingId");
    		String trainingName = rs.getString("trainingName");
    		int availableSeats = rs.getInt("availableSeats");
    		list.add(new Training(trainingId,trainingName,availableSeats));
            System.out.println("Account Fetched!!!");

        }
        
        conn.close();
        stmt.close();
        
	} catch (SQLException e) {
		
		System.out.println("Issues while Fetch Value from Database  : " + e);
	}
		
		
		return list;
	}

	public static int updateDetails(int trainingId) {
		int n = 0;
		
		DatabaseUtility dbU = new DatabaseUtility();
		try {
		Connection conn = dbU.connectToDatabase();
		String sql2 = "UPDATE training set availableSeats = availableSeats-1 where trainingId= ?";
		stmt = conn.prepareStatement(sql2);
		stmt.setInt(1, trainingId);
		stmt.executeUpdate();
		sql2= "SELECT availableSeats from training where trainingId='" +trainingId+ "'";
		ResultSet rs1=stmt.executeQuery(sql2);
		while(rs1.next()) {
			
			n= rs1.getInt("availableSeats");
		}
		
		conn.close();
        stmt.close();
        
        
	} catch (SQLException e) {
		
		System.out.println("Issues while Update Value into Database  : " + e);
	}
		return n;
		
	}

}
