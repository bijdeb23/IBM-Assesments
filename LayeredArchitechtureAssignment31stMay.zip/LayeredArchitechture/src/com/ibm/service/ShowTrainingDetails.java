package com.ibm.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibm.bean.Training;
import com.ibm.dao.TrainingDao;

/**
 * Servlet implementation class ShowTrainingDetails
 */
@WebServlet("/showTraining")
public class ShowTrainingDetails extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
	       ArrayList<Training> list= TrainingDao.trainingDetails();
	       
			for(Training t:list)
				{	
				out.println("<table align=center>");
				out.println(" <tr><th>Training Id</th><th>Training Name</th><th>Available Seats</th><th></th></tr>");
				out.println("<tr><td>"+t.getTrainingId()+"</td><td>"+t.getTrainingName()+"</td><td>"+t.getAvailableSeats()+"</td><td><a href=enroll?trainingId="+t.getTrainingId()+">Enroll</a></td></tr>");
				out.println("</table>");
				}
			list.clear();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
