package com.ibm.bean;

public class Training {
	
	private String trainingName;
    private	int trainingId,availableSeats;
    
	public String getTrainingName() {
		return trainingName;
	}
	public void setTrainingName(String trainingName) {
		this.trainingName = trainingName;
	}
	public int getTrainingId() {
		return trainingId;
	}
	public void setTrainingId(int trainingId) {
		this.trainingId = trainingId;
	}
	public int getAvailableSeats() {
		return availableSeats;
	}
	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}
	
	public Training(int trainingId, String trainingName, int availableSeats) {
		super();
		this.trainingName = trainingName;
		this.trainingId = trainingId;
		this.availableSeats = availableSeats;
	}

}
